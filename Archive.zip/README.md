Document your refactoring choices here. Delete this file if you choose to use a PDF or txt file format instead.
